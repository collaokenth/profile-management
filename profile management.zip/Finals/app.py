from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
# Database configuration
db_config = {
    'user': 'root',
    'password': '',  # Add your database password
    'host': 'localhost',
    'database': 'profile_management'
}

# Helper function to connect to the database
def get_db_connection():
    return mysql.connector.connect(**db_config)

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

# Load user for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    if user:
        return User(user['id'], user['username'], user['password'])
    return None

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO users (username, password) VALUES (%s, %s)', (username, hashed_password))
        conn.commit()
        cursor.close()
        conn.close()

        flash('Account created successfully!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user and bcrypt.check_password_hash(user['password'], password):
            login_user(User(user['id'], user['username'], user['password']))
            return redirect(url_for('index'))
        else:
            flash('Login unsuccessful. Please check your username and password.', 'danger')
    return render_template('login.html')

# Logout route
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# Home page showing profiles
@app.route('/')
@login_required
def index():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM profiles WHERE user_id = %s', (current_user.id,))
    profiles = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('index.html', profiles=profiles)

# Add profile route
@app.route('/add', methods=['POST'])
@login_required
def add_profile():
    name = request.form['name']
    age = request.form['age']
    date_of_birth = request.form['date_of_birth']

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO profiles (name, age, date_of_birth, user_id) VALUES (%s, %s, %s, %s)',
                   (name, age, date_of_birth, current_user.id))
    conn.commit()
    cursor.close()
    conn.close()

    flash('Profile added successfully!', 'success')
    return redirect(url_for('index'))

# Delete profile route
@app.route('/delete/<int:id>')
@login_required
def delete_profile(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM profiles WHERE id = %s AND user_id = %s', (id, current_user.id))
    conn.commit()
    cursor.close()
    conn.close()

    flash('Profile deleted successfully!', 'success')
    return redirect(url_for('index'))

# Update profile route
@app.route('/update/<int:id>', methods=['GET', 'POST'])
@login_required
def update_profile(id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM profiles WHERE id = %s AND user_id = %s', (id, current_user.id))
    profile = cursor.fetchone()

    if not profile:
        flash('Profile not found.', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        date_of_birth = request.form['date_of_birth']
        cursor.execute('UPDATE profiles SET name = %s, age = %s, date_of_birth = %s WHERE id = %s AND user_id = %s',
                       (name, age, date_of_birth, id, current_user.id))
        conn.commit()
        cursor.close()
        conn.close()

        flash('Profile updated successfully!', 'success')
        return redirect(url_for('index'))

    cursor.close()
    conn.close()
    return render_template('update.html', profile=profile)

# Run the application
if __name__ == '__main__':
    app.run(debug=True)
